rm submission.zip
zip submission.zip *
